package com.pixeltrice.springbootOTPapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootOtpAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
