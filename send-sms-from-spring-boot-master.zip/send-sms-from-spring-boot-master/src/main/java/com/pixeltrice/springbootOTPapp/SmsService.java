package com.pixeltrice.springbootOTPapp;

import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;


@Component
	public class SmsService {

	    
	    private final String ACCOUNT_SID ="AC08539d18d355d00fd9f470a97b4280d3";

	    private final String AUTH_TOKEN = "f57b66456a74f164bfa68dd0db10615b";

	    private final String FROM_NUMBER = "+12765660588";

	    public void send(SmsPojo sms) {
	    	Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

	        Message message = Message.creator(new PhoneNumber(sms.getTo()), new PhoneNumber(FROM_NUMBER), sms.getMessage())
	                .create();
	        System.out.println("here is my id:"+message.getSid());// Unique resource ID created to manage this transaction

	    }

	    public void receive(MultiValueMap<String, String> smscallback) {
	    }
	
}
