package com.capstone.hackinc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HackincApplication {

	public static void main(String[] args) {
		SpringApplication.run(HackincApplication.class, args);
	}

}
