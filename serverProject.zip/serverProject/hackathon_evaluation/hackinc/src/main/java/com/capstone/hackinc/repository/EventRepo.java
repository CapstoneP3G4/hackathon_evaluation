package com.capstone.hackinc.repository;

public class EventRepo {

}
