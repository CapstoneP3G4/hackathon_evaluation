package com.capstone.hackinc.controller;

public class EventController {

}
