package com.fullstackbackend.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.fullstackbackend.model.Ideas;
import com.fullstackbackend.model.Team;
import com.fullstackbackend.repository.IdeasRepository;

@RestController
@CrossOrigin("http://localhost:3000")
public class IdeasController {
	
	@Autowired
	private IdeasRepository ideaRepository;
	
//	@PostMapping("/updatedIdea")
//    Ideas newIdea(@RequestBody Ideas newIdea) {
//		Ideas idea = findById(newIdea.getIdeaId()).get();
//		idea.setProblemStatement(newIdea.getProblemStatement());
//		idea.setDescription(newIdea.getDescription());
//		
//        return ideaRepository.save(idea);
//    }
	

	@GetMapping("/getIdea")
	List<Ideas> getAllIdeas(){
		return ideaRepository.findAll();
	}
	
	   @PostMapping("/updatedIdea")
	   public Ideas updatedIdea(@RequestBody Ideas newIdea) {
		   Ideas existingData = ideaRepository.findById(newIdea.getIdeaId()).get();
		   existingData.setProblemStatement(newIdea.getProblemStatement());
		   existingData.setDescription(newIdea.getDescription());
		   return ideaRepository.save(existingData);
	   }
}
